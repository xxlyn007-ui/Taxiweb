import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useLocation } from "wouter";
import { type User } from "@workspace/api-client-react";

interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  login: (token: string, user: User) => void;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [, setLocation] = useLocation();

  useEffect(() => {
    try {
      const storedToken = localStorage.getItem("taxi_token");
      const storedUser = localStorage.getItem("taxi_user");
      
      if (storedToken && storedUser) {
        setToken(storedToken);
        setUser(JSON.parse(storedUser));
      }
    } catch (e) {
      console.error("Failed to restore auth session", e);
    } finally {
      setIsLoading(false);
    }
  }, []);

  const login = (newToken: string, newUser: User) => {
    localStorage.setItem("taxi_token", newToken);
    localStorage.setItem("taxi_user", JSON.stringify(newUser));
    setToken(newToken);
    setUser(newUser);
    
    // Redirect based on role
    if (newUser.role === 'admin') setLocation("/admin");
    else if (newUser.role === 'driver') setLocation("/driver");
    else setLocation("/passenger");
  };

  const logout = () => {
    localStorage.removeItem("taxi_token");
    localStorage.removeItem("taxi_user");
    setToken(null);
    setUser(null);
    setLocation("/login");
  };

  return (
    <AuthContext.Provider value={{ user, token, isLoading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}

export function useAuthHeaders() {
  const { token } = useAuth();
  return {
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {})
    }
  };
}
