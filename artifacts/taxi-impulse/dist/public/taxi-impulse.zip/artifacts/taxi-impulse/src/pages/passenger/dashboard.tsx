import { useState, useEffect } from "react";
import { Link } from "wouter";

import { MainLayout } from "@/components/layout/main-layout";
import { useOrdersQuery, useCreateOrderMutation, useEstimatePriceMutation, useUpdateOrderMutation, useRateOrderMutation } from "@/hooks/use-orders";
import { useCitiesQuery, useTariffsQuery } from "@/hooks/use-admin";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { formatMoney } from "@/lib/utils";
import { OrderChat } from "@/components/chat/order-chat";
import { SupportChat } from "@/components/support/support-chat";
import { RatingModal } from "@/components/rating/rating-modal";
import {
  MapPin, Clock, Car, X, ChevronRight, Loader2,
  Navigation, Phone, MessageCircle, Star, ChevronDown,
  Headphones, UserPlus
} from "lucide-react";
import { cn } from "@/lib/utils";

const CITY_KEY = "taxi_passenger_city";

export default function PassengerDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();

  const { data: cities } = useCitiesQuery();
  const { data: tariffs } = useTariffsQuery();
  const { data: orders, isLoading: ordersLoading } = useOrdersQuery({ passengerId: user?.id });

  const createOrder = useCreateOrderMutation();
  const estimatePrice = useEstimatePriceMutation();
  const updateOrder = useUpdateOrderMutation();
  const rateOrder = useRateOrderMutation();

  const savedCity = localStorage.getItem(CITY_KEY) || "Красноярск";
  const [city, setCity] = useState(savedCity);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [tariffId, setTariffId] = useState<number | null>(null);
  const [estimate, setEstimate] = useState<{ price: number; distance: number; duration: number } | null>(null);
  const [step, setStep] = useState<"form" | "confirm">("form");
  const [showChat, setShowChat] = useState(false);
  const [showSupport, setShowSupport] = useState(false);
  const [showCityPicker, setShowCityPicker] = useState(false);
  const [ratingOrderId, setRatingOrderId] = useState<number | null>(null);
  const [ratingDriverName, setRatingDriverName] = useState("");

  useEffect(() => { localStorage.setItem(CITY_KEY, city); }, [city]);

  // localStorage key for tracking orders the passenger already dismissed/rated
  const dismissedKey = `dismissed_ratings_${user?.id}`;
  const getDismissed = (): Set<number> => {
    try { return new Set(JSON.parse(localStorage.getItem(dismissedKey) || "[]")); }
    catch { return new Set(); }
  };
  const markDismissed = (id: number) => {
    const s = getDismissed(); s.add(id);
    localStorage.setItem(dismissedKey, JSON.stringify([...s]));
  };

  // Show rating modal for any completed order that has no rating and wasn't dismissed
  useEffect(() => {
    if (!orders || ratingOrderId) return;
    const dismissed = getDismissed();
    const unrated = orders.find(o => o.status === 'completed' && !o.rating && !dismissed.has(o.id));
    if (unrated) {
      setRatingOrderId(unrated.id);
      setRatingDriverName((unrated as any).driverName || 'водителя');
    }
  }, [orders]);

  const handleRate = async (rating: number) => {
    if (!ratingOrderId) return;
    try {
      await rateOrder.mutateAsync({ id: ratingOrderId, data: { rating } });
      markDismissed(ratingOrderId);
      toast({ title: "Спасибо за оценку!" });
    } catch {
      toast({ title: "Не удалось отправить оценку", variant: "destructive" });
    } finally {
      setRatingOrderId(null);
    }
  };

  const activeOrder = orders?.find(o => ['pending', 'accepted', 'in_progress'].includes(o.status));
  const recentOrders = orders?.filter(o => ['completed', 'cancelled'].includes(o.status)).slice(0, 5);

  const handleEstimate = async () => {
    if (!from.trim() || !to.trim()) {
      toast({ title: "Укажите адреса", variant: "destructive" });
      return;
    }
    if (!tariffId) {
      toast({ title: "Выберите тариф", variant: "destructive" });
      return;
    }
    try {
      const res = await estimatePrice.mutateAsync({ data: { city, fromAddress: from, toAddress: to, tariffId } });
      setEstimate({ price: res.estimatedPrice, distance: res.estimatedDistance, duration: res.estimatedDuration });
      setStep("confirm");
    } catch {
      toast({ title: "Ошибка расчёта", variant: "destructive" });
    }
  };

  const handleOrder = async () => {
    try {
      await createOrder.mutateAsync({ data: { passengerId: user!.id, city, fromAddress: from, toAddress: to, tariffId: tariffId! } });
      toast({ title: "Заказ создан!", description: "Ищем водителя..." });
      setStep("form"); setEstimate(null); setFrom(""); setTo("");
    } catch {
      toast({ title: "Ошибка создания заказа", variant: "destructive" });
    }
  };

  const handleCancel = async (orderId: number) => {
    if (!confirm("Отменить заказ?")) return;
    try {
      await updateOrder.mutateAsync({ id: orderId, data: { status: 'cancelled' } });
      toast({ title: "Заказ отменён" });
    } catch {
      toast({ title: "Ошибка", variant: "destructive" });
    }
  };

  const statusInfo: Record<string, { label: string; color: string; bg: string }> = {
    pending: { label: "Ищем водителя...", color: "text-amber-400", bg: "bg-amber-500/10 border-amber-500/20" },
    accepted: { label: "Водитель едет к вам", color: "text-violet-400", bg: "bg-violet-500/10 border-violet-500/20" },
    in_progress: { label: "Вы в поездке", color: "text-emerald-400", bg: "bg-emerald-500/10 border-emerald-500/20" },
  };

  return (
    <MainLayout allowedRoles={['passenger']}>
      <div className="max-w-lg mx-auto pb-6 space-y-0">

        {/* Map-style hero when active order */}
        {activeOrder ? (
          <div className="relative rounded-3xl overflow-hidden mb-4" style={{ minHeight: 260 }}>
            {/* Animated map background */}
            <div className="absolute inset-0 bg-[#0d0d1f]">
              <div className="absolute inset-0" style={{
                backgroundImage: `
                  linear-gradient(rgba(109,40,217,0.05) 1px, transparent 1px),
                  linear-gradient(90deg, rgba(109,40,217,0.05) 1px, transparent 1px)
                `,
                backgroundSize: '40px 40px'
              }} />
              {activeOrder.status === 'pending' && (
                <>
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-24 h-24 bg-violet-600/10 rounded-full animate-ping" />
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 bg-violet-600/20 rounded-full animate-ping" style={{ animationDelay: '0.3s' }} />
                  <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 bg-violet-600/40 rounded-full" />
                </>
              )}
              {activeOrder.status !== 'pending' && (
                <>
                  <div className="absolute top-1/3 left-1/3 w-3 h-3 bg-violet-500/30 rounded-full" />
                  <div className="absolute top-2/3 left-2/3 w-2 h-2 bg-emerald-500/20 rounded-full" />
                  <div className="absolute top-1/2 right-1/4 w-2 h-2 bg-violet-500/20 rounded-full" />
                </>
              )}
            </div>

            {/* Status badge */}
            <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
              <div className={cn("flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs font-medium", statusInfo[activeOrder.status]?.bg, statusInfo[activeOrder.status]?.color)}>
                {activeOrder.status === 'pending' && <Navigation className="w-3 h-3 animate-pulse" />}
                {activeOrder.status === 'accepted' && <Car className="w-3 h-3" />}
                {activeOrder.status === 'in_progress' && <div className="w-1.5 h-1.5 bg-emerald-400 rounded-full animate-pulse" />}
                {statusInfo[activeOrder.status]?.label}
              </div>
              <div className="text-lg font-bold text-white bg-black/40 backdrop-blur-sm px-3 py-1 rounded-full">
                {formatMoney(activeOrder.price || 0)}
              </div>
            </div>

            {/* Route info at bottom of map */}
            <div className="absolute bottom-0 left-0 right-0 px-4 py-4 bg-gradient-to-t from-[#0d0d1f] to-transparent">
              <div className="flex items-start gap-3">
                <div className="flex flex-col items-center gap-1 pt-0.5">
                  <div className="w-2.5 h-2.5 rounded-full bg-violet-500 border-2 border-[#0d0d1f]" />
                  <div className="w-0.5 h-5 bg-white/10" />
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 border-2 border-[#0d0d1f]" />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-sm text-white/70 truncate">{activeOrder.fromAddress}</div>
                  <div className="text-sm text-white/50 mt-1.5 truncate">{activeOrder.toAddress}</div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Hero greeting (no active order) */
          <div className="relative rounded-3xl overflow-hidden mb-4 px-5 py-6" style={{ background: 'linear-gradient(135deg, #13132b 0%, #1a0d2e 100%)' }}>
            <div className="absolute top-0 right-0 w-32 h-32 bg-violet-600/10 rounded-full -translate-y-8 translate-x-8" />
            <div className="relative z-10">
              <p className="text-white/50 text-sm">Добро пожаловать,</p>
              <h2 className="text-2xl font-bold text-white mt-0.5">{user?.name?.split(' ')[0]} 👋</h2>
              <p className="text-white/40 text-sm mt-2">Куда едем сегодня?</p>
            </div>
          </div>
        )}

        {/* Driver info card (shown when driver assigned) */}
        {activeOrder?.driverName && (
          <div className="bg-[#0d0d1f] border border-white/[0.08] rounded-2xl p-4 mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-violet-600/20 flex items-center justify-center flex-shrink-0 text-violet-300 font-bold text-lg">
                {activeOrder.driverName.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <span className="text-white font-semibold">{activeOrder.driverName}</span>
                  <div className="flex items-center gap-0.5 text-amber-400">
                    <Star className="w-3 h-3 fill-current" />
                    <span className="text-xs">4.9</span>
                  </div>
                </div>
                <div className="text-sm text-white/50 mt-0.5">
                  {activeOrder.driverCar} · <span className="text-white/70 font-medium">{activeOrder.driverCarNumber}</span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowChat(true)}
                  className="w-10 h-10 rounded-xl bg-violet-600/20 hover:bg-violet-600/30 flex items-center justify-center transition-colors"
                >
                  <MessageCircle className="w-4 h-4 text-violet-400" />
                </button>
                <a
                  href={`tel:${activeOrder.driverPhone}`}
                  className="w-10 h-10 rounded-xl bg-white/[0.06] hover:bg-white/10 flex items-center justify-center transition-colors"
                >
                  <Phone className="w-4 h-4 text-white/60" />
                </a>
              </div>
            </div>
          </div>
        )}

        {/* Searching animation (pending, no driver) */}
        {activeOrder?.status === 'pending' && !activeOrder.driverName && (
          <div className="bg-[#0d0d1f] border border-amber-500/20 rounded-2xl p-4 mb-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/10 flex items-center justify-center">
                <Loader2 className="w-5 h-5 text-amber-400 animate-spin" />
              </div>
              <div>
                <div className="text-sm font-medium text-white">Ищем ближайшего водителя</div>
                <div className="text-xs text-white/40 mt-0.5">Обычно это занимает 1–3 минуты</div>
              </div>
            </div>
          </div>
        )}

        {/* Cancel button for pending order */}
        {activeOrder?.status === 'pending' && (
          <button
            onClick={() => handleCancel(activeOrder.id)}
            className="w-full mb-4 py-3 rounded-2xl bg-red-500/10 hover:bg-red-500/15 border border-red-500/20 text-red-400 text-sm font-medium transition-all flex items-center justify-center gap-2"
          >
            <X className="w-4 h-4" /> Отменить заказ
          </button>
        )}

        {/* New order form */}
        {!activeOrder && (
          <div className="bg-[#0d0d1f] border border-white/[0.08] rounded-3xl overflow-hidden mb-4">
            {/* City selector */}
            <button
              onClick={() => setShowCityPicker(!showCityPicker)}
              className="w-full flex items-center justify-between px-5 py-3.5 border-b border-white/[0.06] hover:bg-white/[0.02] transition-colors"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-7 h-7 rounded-lg bg-violet-600/20 flex items-center justify-center">
                  <MapPin className="w-3.5 h-3.5 text-violet-400" />
                </div>
                <span className="text-sm font-medium text-white">{city}</span>
              </div>
              <ChevronDown className={cn("w-4 h-4 text-white/30 transition-transform", showCityPicker && "rotate-180")} />
            </button>

            {showCityPicker && (
              <div className="grid grid-cols-2 gap-1.5 p-3 border-b border-white/[0.06]">
                {cities?.map(c => (
                  <button
                    key={c.id}
                    onClick={() => { setCity(c.name); setShowCityPicker(false); }}
                    className={cn(
                      "px-3 py-2 rounded-xl text-sm text-left transition-all",
                      city === c.name
                        ? "bg-violet-600/20 border border-violet-600/30 text-violet-300"
                        : "bg-white/[0.04] hover:bg-white/[0.08] text-white/60"
                    )}
                  >
                    {c.name}
                  </button>
                ))}
              </div>
            )}

            {/* Address inputs */}
            <div className="px-5 py-4">
              <div className="flex items-stretch gap-3">
                <div className="flex flex-col items-center py-1 gap-1">
                  <div className="w-2.5 h-2.5 rounded-full bg-violet-500" />
                  <div className="flex-1 w-0.5 bg-white/[0.08] min-h-[24px]" />
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                </div>
                <div className="flex-1 space-y-2">
                  <input
                    value={from}
                    onChange={e => { setFrom(e.target.value); setEstimate(null); setStep("form"); }}
                    placeholder="Откуда забрать?"
                    className="w-full bg-white/[0.05] hover:bg-white/[0.07] border border-white/[0.08] rounded-xl px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:ring-2 focus:ring-violet-500/40 transition-all text-sm"
                  />
                  <input
                    value={to}
                    onChange={e => { setTo(e.target.value); setEstimate(null); setStep("form"); }}
                    placeholder="Куда едем?"
                    className="w-full bg-white/[0.05] hover:bg-white/[0.07] border border-white/[0.08] rounded-xl px-4 py-3 text-white placeholder:text-white/30 focus:outline-none focus:ring-2 focus:ring-violet-500/40 transition-all text-sm"
                  />
                </div>
              </div>
            </div>

            {/* Tariff selection */}
            <div className="px-5 pb-4">
              <div className="text-xs text-white/30 uppercase tracking-wider mb-3">Класс автомобиля</div>
              <div className="grid grid-cols-2 gap-2">
                {tariffs?.filter(t => t.isActive).map(tariff => (
                  <button
                    key={tariff.id}
                    onClick={() => { setTariffId(tariff.id); setEstimate(null); setStep("form"); }}
                    className={cn(
                      "p-3.5 rounded-2xl border text-left transition-all",
                      tariffId === tariff.id
                        ? "bg-violet-600/20 border-violet-600/40 shadow-lg shadow-violet-600/10"
                        : "bg-white/[0.03] border-white/[0.06] hover:border-white/15"
                    )}
                  >
                    <div className="flex items-center justify-between mb-1.5">
                      <div className={cn("w-7 h-7 rounded-lg flex items-center justify-center text-sm",
                        tariffId === tariff.id ? "bg-violet-600/30" : "bg-white/5"
                      )}>
                        {tariff.name.includes('Эконом') ? '🚗' : tariff.name.includes('Комфорт') ? '🚙' : tariff.name.includes('Бизнес') ? '🚘' : '🚖'}
                      </div>
                      <span className="text-xs text-violet-400 font-medium">от {formatMoney(tariff.minPrice)}</span>
                    </div>
                    <div className="text-sm font-semibold text-white">{tariff.name}</div>
                    <div className="text-xs text-white/40 mt-0.5">{tariff.pricePerKm} ₽/км</div>
                  </button>
                ))}
              </div>
            </div>

            {/* CTA */}
            <div className="px-5 pb-5">
              {step === "confirm" && estimate ? (
                <div className="space-y-3">
                  <div className="bg-violet-600/10 border border-violet-600/20 rounded-2xl p-4 flex items-center justify-between">
                    <div>
                      <div className="text-xs text-white/40 mb-0.5">Стоимость поездки</div>
                      <div className="text-2xl font-bold text-white">{formatMoney(estimate.price)}</div>
                    </div>
                    <div className="text-right space-y-1">
                      <div className="flex items-center gap-1.5 text-xs text-white/40 justify-end">
                        <Clock className="w-3 h-3" /> ~{estimate.duration} мин
                      </div>
                      <div className="flex items-center gap-1.5 text-xs text-white/40 justify-end">
                        <MapPin className="w-3 h-3" /> {estimate.distance.toFixed(1)} км
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => { setStep("form"); setEstimate(null); }}
                      className="px-4 py-3 rounded-2xl bg-white/5 hover:bg-white/10 text-white/60 text-sm transition-all"
                    >
                      Изменить
                    </button>
                    <button
                      onClick={handleOrder}
                      disabled={createOrder.isPending}
                      className="flex-1 py-3 rounded-2xl bg-violet-600 hover:bg-violet-500 text-white font-semibold text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-violet-600/25"
                    >
                      {createOrder.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : <>Заказать <ChevronRight className="w-4 h-4" /></>}
                    </button>
                  </div>
                </div>
              ) : (
                <button
                  onClick={handleEstimate}
                  disabled={estimatePrice.isPending}
                  className="w-full py-3.5 rounded-2xl bg-violet-600 hover:bg-violet-500 text-white font-semibold transition-all flex items-center justify-center gap-2 shadow-lg shadow-violet-600/25 text-sm"
                >
                  {estimatePrice.isPending ? <Loader2 className="w-4 h-4 animate-spin" /> : "Рассчитать стоимость"}
                </button>
              )}
            </div>
          </div>
        )}

        {/* Support button */}
        <button
          onClick={() => setShowSupport(true)}
          className="w-full flex items-center gap-3 px-4 py-3.5 bg-[#0d0d1f] border border-white/[0.08] rounded-2xl hover:border-violet-500/20 transition-all mb-3"
        >
          <div className="w-9 h-9 rounded-xl bg-violet-600/20 flex items-center justify-center">
            <Headphones className="w-4 h-4 text-violet-400" />
          </div>
          <div className="text-left">
            <div className="text-sm font-medium text-white">Техподдержка</div>
            <div className="text-xs text-white/40">Онлайн · Ответим быстро</div>
          </div>
          <ChevronRight className="w-4 h-4 text-white/20 ml-auto" />
        </button>

        {/* Become a driver button */}
        <Link href="/register-driver">
          <div className="w-full flex items-center gap-3 px-4 py-3.5 bg-[#0d0d1f] border border-white/[0.08] rounded-2xl hover:border-violet-500/20 transition-all mb-4 cursor-pointer">
            <div className="w-9 h-9 rounded-xl bg-violet-600/10 flex items-center justify-center">
              <UserPlus className="w-4 h-4 text-violet-300" />
            </div>
            <div className="text-left">
              <div className="text-sm font-medium text-white">Стать водителем</div>
              <div className="text-xs text-white/40">Зарабатывайте с нами</div>
            </div>
            <ChevronRight className="w-4 h-4 text-white/20 ml-auto" />
          </div>
        </Link>

        {/* Recent rides */}
        {recentOrders && recentOrders.length > 0 && (
          <div>
            <div className="text-xs text-white/30 uppercase tracking-wider mb-3 px-1">История поездок</div>
            <div className="bg-[#0d0d1f] border border-white/[0.08] rounded-2xl overflow-hidden">
              {recentOrders.map((order, i) => (
                <div key={order.id} className={cn(
                  "flex items-center gap-3 px-4 py-3.5",
                  i < recentOrders.length - 1 && "border-b border-white/[0.04]"
                )}>
                  <div className={cn(
                    "w-9 h-9 rounded-xl flex items-center justify-center text-xs flex-shrink-0",
                    order.status === 'completed' ? "bg-emerald-500/10" : "bg-red-500/10"
                  )}>
                    {order.status === 'completed' ? '✓' : '✕'}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm text-white/80 truncate">{order.toAddress}</div>
                    <div className="text-xs text-white/30 mt-0.5">{order.city}</div>
                  </div>
                  <div className={cn("text-sm font-semibold flex-shrink-0",
                    order.status === 'completed' ? "text-white" : "text-red-400"
                  )}>
                    {order.status === 'completed' ? formatMoney(order.price || 0) : "Отменён"}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Chat modal */}
      {showChat && activeOrder && (
        <OrderChat orderId={activeOrder.id} onClose={() => setShowChat(false)} />
      )}

      {/* Support chat modal */}
      {showSupport && (
        <SupportChat onClose={() => setShowSupport(false)} />
      )}

      {/* Rating modal */}
      {ratingOrderId && (
        <RatingModal
          driverName={ratingDriverName}
          onRate={handleRate}
          onSkip={() => { markDismissed(ratingOrderId); setRatingOrderId(null); }}
          isPending={rateOrder.isPending}
        />
      )}
    </MainLayout>
  );
}
