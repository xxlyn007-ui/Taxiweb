import { useState } from "react";
import { useLogin } from "@workspace/api-client-react";
import { useAuth } from "@/hooks/use-auth";
import { Link, useSearch } from "wouter";
import { Loader2, Eye, EyeOff, Shield } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

export default function Login() {
  const { login } = useAuth();
  const { toast } = useToast();
  const loginMutation = useLogin();
  const search = useSearch();
  const isAdminMode = search?.includes("admin=1");

  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);

  const fillDemo = (role: "passenger" | "driver" | "admin") => {
    if (role === "admin") { setPhone("79991234567"); setPassword("admin123"); }
    else if (role === "driver") { setPhone("79991234568"); setPassword("driver123"); }
    else { setPhone("79991234569"); setPassword("pass123"); }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!phone || !password) {
      toast({ title: "Введите телефон и пароль", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      const res = await loginMutation.mutateAsync({ data: { phone, password } });
      login(res.token, res.user);
    } catch (err: any) {
      const msg = err?.response?.data?.error || err?.message || "Неверный телефон или пароль";
      toast({ title: "Ошибка входа", description: msg, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#07070f] flex flex-col md:flex-row">
      {/* Left hero */}
      <div className="hidden md:flex flex-1 flex-col items-center justify-center p-12 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-violet-950/60 via-[#07070f] to-[#07070f]" />
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-violet-600/10 rounded-full blur-[100px]" />
        <div className="relative z-10 text-center max-w-sm">
          <div className="mx-auto mb-8">
            <img src="/logo.png" alt="TAXI IMPULSE" className="w-56 h-56 object-contain drop-shadow-2xl brightness-125 saturate-150" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-4 leading-tight">TAXI<br/>IMPULSE</h1>
          <p className="text-violet-300/70 text-lg">Сервис такси<br/>Красноярского края</p>
          <div className="mt-12 flex flex-col gap-3 text-sm text-left">
            {["Быстрая подача", "Проверенные водители", "Фиксированная цена"].map(f => (
              <div key={f} className="flex items-center gap-3 text-white/60">
                <div className="w-1.5 h-1.5 bg-violet-500 rounded-full flex-shrink-0" />
                {f}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Right form */}
      <div className="flex-1 flex items-center justify-center p-6 relative">
        {/* Admin secret link */}
        <Link href="/login?admin=1">
          <div className={cn(
            "absolute top-6 right-6 flex items-center gap-1.5 text-xs transition-all cursor-pointer",
            isAdminMode ? "text-violet-400" : "text-white/10 hover:text-white/30"
          )}>
            <Shield className="w-3.5 h-3.5" />
            {isAdminMode && <span>Режим администратора</span>}
          </div>
        </Link>

        <div className="w-full max-w-sm">
          <div className="md:hidden flex items-center gap-2 mb-8">
            <img src="/logo.png" alt="TAXI IMPULSE" className="w-12 h-12 object-contain brightness-125 saturate-150" />
            <span className="text-white font-bold text-lg">TAXI IMPULSE</span>
          </div>

          <h2 className="text-2xl font-bold text-white mb-1">
            {isAdminMode ? "Вход администратора" : "Вход в систему"}
          </h2>
          <p className="text-white/40 text-sm mb-8">
            {isAdminMode ? "Управление платформой" : "Пассажир или водитель"}
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs text-white/50 mb-2 uppercase tracking-wider">Номер телефона</label>
              <input
                type="tel"
                value={phone}
                onChange={e => setPhone(e.target.value)}
                placeholder="79990000000"
                className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 text-white placeholder:text-white/20 focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-500/50 transition-all"
              />
            </div>

            <div>
              <label className="block text-xs text-white/50 mb-2 uppercase tracking-wider">Пароль</label>
              <div className="relative">
                <input
                  type={showPw ? "text" : "password"}
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3.5 pr-12 text-white placeholder:text-white/20 focus:outline-none focus:ring-2 focus:ring-violet-500/50 focus:border-violet-500/50 transition-all"
                />
                <button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white/60 transition-colors">
                  {showPw ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 rounded-xl bg-violet-600 hover:bg-violet-500 text-white font-semibold transition-all mt-2 flex items-center justify-center gap-2 shadow-lg shadow-violet-600/30"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : "Войти"}
            </button>
          </form>

          <div className="mt-6 text-center text-sm text-white/30">
            Нет аккаунта?{" "}
            <Link href="/register" className="text-violet-400 hover:text-violet-300 transition-colors font-medium">
              Зарегистрироваться
            </Link>
          </div>

          {/* Demo helpers */}
          <div className="mt-8 pt-6 border-t border-white/5">
            <p className="text-xs text-center text-white/20 mb-3">Быстрый вход для демо</p>
            <div className="flex gap-2 justify-center">
              <button onClick={() => fillDemo('passenger')} className="text-xs bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-lg text-white/40 hover:text-white/70 transition-all">Пассажир</button>
              <button onClick={() => fillDemo('driver')} className="text-xs bg-white/5 hover:bg-white/10 px-3 py-1.5 rounded-lg text-white/40 hover:text-white/70 transition-all">Водитель</button>
              {isAdminMode && <button onClick={() => fillDemo('admin')} className="text-xs bg-violet-600/20 hover:bg-violet-600/30 px-3 py-1.5 rounded-lg text-violet-400 transition-all">Админ</button>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
