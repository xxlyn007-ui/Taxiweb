import { Switch, Route, Router as WouterRouter, Redirect } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider, useAuth } from "@/hooks/use-auth";
import NotFound from "@/pages/not-found";

import Login from "@/pages/login";
import Register from "@/pages/register";
import RegisterDriver from "@/pages/register-driver";
import PassengerDashboard from "@/pages/passenger/dashboard";
import PassengerHistory from "@/pages/passenger/history";
import DriverDashboard from "@/pages/driver/dashboard";
import AvailableOrders from "@/pages/driver/orders";
import AdminDashboard from "@/pages/admin/dashboard";
import AdminOrders from "@/pages/admin/orders";
import AdminTariffs from "@/pages/admin/tariffs";
import AdminDrivers from "@/pages/admin/drivers";
import AdminSupport from "@/pages/admin/support";
import SupportPage from "@/pages/support";
import { MainLayout } from "@/components/layout/main-layout";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchInterval: 8000,
      retry: 1,
    }
  }
});

function RootRedirect() {
  const { user, isLoading } = useAuth();
  if (isLoading) return <div className="min-h-screen bg-[#07070f]" />;
  if (!user) return <Redirect to="/login" />;
  if (user.role === 'admin') return <Redirect to="/admin" />;
  if (user.role === 'driver') return <Redirect to="/driver" />;
  return <Redirect to="/passenger" />;
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={RootRedirect} />
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/register-driver" component={RegisterDriver} />

      <Route path="/passenger" component={PassengerDashboard} />
      <Route path="/passenger/history" component={PassengerHistory} />

      <Route path="/driver" component={DriverDashboard} />
      <Route path="/driver/orders" component={AvailableOrders} />

      <Route path="/admin" component={AdminDashboard} />
      <Route path="/admin/orders" component={AdminOrders} />
      <Route path="/admin/tariffs" component={AdminTariffs} />
      <Route path="/admin/drivers" component={AdminDrivers} />
      <Route path="/admin/support" component={AdminSupport} />
      <Route path="/support" component={SupportPage} />

      <Route path="/admin/users" component={() => (
        <MainLayout allowedRoles={['admin']}>
          <div className="p-8 text-center text-white/30 text-sm">Раздел в разработке</div>
        </MainLayout>
      )} />

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AuthProvider>
            <Router />
          </AuthProvider>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
