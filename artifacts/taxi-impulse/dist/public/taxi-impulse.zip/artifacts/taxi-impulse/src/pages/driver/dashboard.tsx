import { useState } from "react";
import { MainLayout } from "@/components/layout/main-layout";
import { useAuth } from "@/hooks/use-auth";
import { useDriversQuery, useUpdateDriverStatusMutation, useUpdateDriverMutation } from "@/hooks/use-drivers";
import { useOrdersQuery, useUpdateOrderMutation } from "@/hooks/use-orders";
import { useCitiesQuery } from "@/hooks/use-admin";
import { formatMoney } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { OrderChat } from "@/components/chat/order-chat";
import { SupportChat } from "@/components/support/support-chat";
import {
  Power, Zap, Phone, MapPin, ChevronRight, Star, Wallet,
  Settings, Check, X, MessageCircle, Car, Headphones, ChevronDown
} from "lucide-react";
import { cn } from "@/lib/utils";
import { useQueryClient } from "@tanstack/react-query";

export default function DriverDashboard() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showCityPicker, setShowCityPicker] = useState(false);
  const [showChat, setShowChat] = useState(false);
  const [showSupport, setShowSupport] = useState(false);

  const { data: drivers, isLoading } = useDriversQuery();
  const { data: cities } = useCitiesQuery();
  const myProfile = drivers?.find(d => d.userId === user?.id);

  const updateStatus = useUpdateDriverStatusMutation();
  const updateDriver = useUpdateDriverMutation();
  const updateOrder = useUpdateOrderMutation();

  const { data: orders } = useOrdersQuery({ driverId: myProfile?.id });
  const activeOrder = orders?.find(o => ['accepted', 'in_progress'].includes(o.status));

  const toggleOnline = async () => {
    if (!myProfile || activeOrder) return;
    const next = myProfile.status === 'online' ? 'offline' : 'online';
    try {
      await updateStatus.mutateAsync({ id: myProfile.id, data: { status: next } });
      queryClient.invalidateQueries({ queryKey: ['/api/orders'] });
    } catch { toast({ title: "Ошибка", variant: "destructive" }); }
  };

  const toggleAutoAssign = async () => {
    if (!myProfile) return;
    try {
      await updateDriver.mutateAsync({ id: myProfile.id, data: { autoAssign: !myProfile.autoAssign } });
      toast({ title: myProfile.autoAssign ? "Авто-назначение выключено" : "Авто-назначение включено" });
    } catch { toast({ title: "Ошибка", variant: "destructive" }); }
  };

  const changeWorkCity = async (city: string) => {
    if (!myProfile) return;
    try {
      await updateDriver.mutateAsync({ id: myProfile.id, data: { workCity: city } });
      toast({ title: `Город изменён на ${city}` });
      setShowCityPicker(false);
    } catch { toast({ title: "Ошибка", variant: "destructive" }); }
  };

  const startTrip = async () => {
    if (!activeOrder) return;
    try { await updateOrder.mutateAsync({ id: activeOrder.id, data: { status: 'in_progress' } }); }
    catch { toast({ title: "Ошибка", variant: "destructive" }); }
  };

  const completeTrip = async () => {
    if (!activeOrder) return;
    try {
      await updateOrder.mutateAsync({ id: activeOrder.id, data: { status: 'completed' } });
      toast({ title: "Поездка завершена! 🎉" });
    } catch { toast({ title: "Ошибка", variant: "destructive" }); }
  };

  const cancelOrder = async () => {
    if (!activeOrder) return;
    if (!confirm("Отменить текущий заказ?")) return;
    try {
      await updateOrder.mutateAsync({ id: activeOrder.id, data: { status: 'cancelled' } });
      toast({ title: "Заказ отменён" });
    } catch { toast({ title: "Ошибка", variant: "destructive" }); }
  };

  if (isLoading) return (
    <MainLayout allowedRoles={['driver']}>
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-2 border-violet-600 border-t-transparent rounded-full animate-spin" />
      </div>
    </MainLayout>
  );

  const isOnline = myProfile?.status === 'online' || myProfile?.status === 'busy';
  const workCity = myProfile?.workCity || myProfile?.city || 'Не указан';

  return (
    <MainLayout allowedRoles={['driver']}>
      <div className="max-w-2xl mx-auto space-y-3 pb-8">

        {/* Status card */}
        <div className="bg-[#0d0d1f] border border-white/[0.08] rounded-3xl p-5">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <button
                onClick={toggleOnline}
                disabled={updateStatus.isPending || !!activeOrder}
                className={cn(
                  "w-14 h-14 rounded-2xl flex items-center justify-center transition-all font-bold shadow-lg",
                  isOnline
                    ? "bg-emerald-500 shadow-emerald-500/25 hover:bg-emerald-400"
                    : "bg-white/10 hover:bg-white/15",
                  activeOrder && "opacity-40 cursor-not-allowed"
                )}
              >
                <Power className={cn("w-6 h-6", isOnline ? "text-white" : "text-white/60")} />
              </button>
              <div>
                <div className="flex items-center gap-2">
                  <span className={cn("text-base font-bold", isOnline ? "text-white" : "text-white/50")}>
                    {myProfile?.status === 'busy' ? "В поездке" : isOnline ? "На линии" : "Оффлайн"}
                  </span>
                  {isOnline && <div className="w-2 h-2 bg-emerald-400 rounded-full animate-pulse" />}
                </div>
                <button
                  onClick={() => setShowCityPicker(!showCityPicker)}
                  className="flex items-center gap-1 text-sm text-white/40 hover:text-white/70 transition-colors mt-0.5"
                >
                  <MapPin className="w-3 h-3" />
                  {workCity}
                  <ChevronDown className={cn("w-3 h-3 ml-0.5 transition-transform", showCityPicker && "rotate-180")} />
                </button>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="text-right">
                <div className="text-xs text-white/30 mb-0.5">Баланс</div>
                <div className="text-sm font-bold text-emerald-400">{formatMoney(myProfile?.balance || 0)}</div>
              </div>
              <div className="text-right">
                <div className="text-xs text-white/30 mb-0.5">Рейтинг</div>
                <div className="text-sm font-bold text-amber-400 flex items-center gap-0.5">
                  <Star className="w-3 h-3 fill-current" />{myProfile?.rating?.toFixed(1) || '5.0'}
                </div>
              </div>
            </div>
          </div>

          {/* City picker */}
          {showCityPicker && (
            <div className="border-t border-white/[0.06] pt-3 mt-1">
              <p className="text-xs text-white/30 uppercase tracking-wider mb-2">Выберите город работы</p>
              <div className="grid grid-cols-2 gap-1.5 max-h-36 overflow-y-auto">
                {cities?.map(c => (
                  <button
                    key={c.id}
                    onClick={() => changeWorkCity(c.name)}
                    className={cn(
                      "px-3 py-2 rounded-xl text-sm text-left transition-all flex items-center justify-between",
                      workCity === c.name
                        ? "bg-violet-600/20 border border-violet-600/30 text-violet-300"
                        : "bg-white/[0.04] hover:bg-white/[0.08] text-white/60"
                    )}
                  >
                    {c.name}
                    {workCity === c.name && <Check className="w-3 h-3" />}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Auto-assign toggle */}
          <div className="flex items-center justify-between border-t border-white/[0.06] pt-4 mt-1">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-violet-600/20 flex items-center justify-center">
                <Zap className="w-4 h-4 text-violet-400" />
              </div>
              <div>
                <div className="text-sm font-medium text-white">Авто-назначение</div>
                <div className="text-xs text-white/30">Приоритет в радиусе 2 км</div>
              </div>
            </div>
            <button
              onClick={toggleAutoAssign}
              disabled={updateDriver.isPending}
              className={cn("relative w-11 h-6 rounded-full transition-all", myProfile?.autoAssign ? "bg-violet-600" : "bg-white/10")}
            >
              <div className={cn("absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-all", myProfile?.autoAssign ? "left-6" : "left-1")} />
            </button>
          </div>
        </div>

        {/* Active order or waiting */}
        {activeOrder ? (
          <div className="bg-[#0d0d1f] border border-violet-600/20 rounded-3xl overflow-hidden">
            <div className="px-5 pt-4 pb-3 border-b border-white/[0.06]">
              <div className="flex items-center justify-between">
                <span className="text-sm font-semibold text-violet-300 uppercase tracking-wider">
                  {activeOrder.status === 'accepted' ? '🚗 Едем к пассажиру' : '▶ Поездка идёт'}
                </span>
                <span className="text-xl font-bold text-white">{formatMoney(activeOrder.price || 0)}</span>
              </div>
            </div>

            {/* Passenger info */}
            <div className="px-5 py-4">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-11 h-11 rounded-2xl bg-violet-600/20 flex items-center justify-center text-violet-300 font-bold text-lg flex-shrink-0">
                  {activeOrder.passengerName?.charAt(0) || 'П'}
                </div>
                <div className="flex-1">
                  <div className="text-sm font-semibold text-white">{activeOrder.passengerName}</div>
                  <div className="text-xs text-white/40">{activeOrder.passengerPhone}</div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => setShowChat(true)}
                    className="w-10 h-10 rounded-xl bg-violet-600/20 hover:bg-violet-600/30 flex items-center justify-center transition-colors"
                  >
                    <MessageCircle className="w-4 h-4 text-violet-400" />
                  </button>
                  <a
                    href={`tel:${activeOrder.passengerPhone}`}
                    className="w-10 h-10 rounded-xl bg-white/[0.06] hover:bg-white/10 flex items-center justify-center transition-colors"
                  >
                    <Phone className="w-4 h-4 text-white/60" />
                  </a>
                </div>
              </div>

              {/* Route */}
              <div className="flex items-stretch gap-3 mb-4">
                <div className="flex flex-col items-center py-0.5 gap-1">
                  <div className="w-2.5 h-2.5 rounded-full bg-violet-500" />
                  <div className="flex-1 w-0.5 bg-white/10 min-h-[20px]" />
                  <div className="w-2.5 h-2.5 rounded-full bg-emerald-500" />
                </div>
                <div className="flex-1 space-y-3">
                  <div>
                    <div className="text-xs text-white/30 mb-0.5">Откуда</div>
                    <div className="text-sm text-white">{activeOrder.fromAddress}</div>
                  </div>
                  <div>
                    <div className="text-xs text-white/30 mb-0.5">Куда</div>
                    <div className="text-sm text-white">{activeOrder.toAddress}</div>
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2">
                <button
                  onClick={cancelOrder}
                  className="px-4 py-3 rounded-2xl bg-red-500/10 hover:bg-red-500/20 text-red-400 text-sm font-medium transition-all flex items-center gap-1.5"
                >
                  <X className="w-4 h-4" /> Отменить
                </button>
                {activeOrder.status === 'accepted' ? (
                  <button
                    onClick={startTrip}
                    disabled={updateOrder.isPending}
                    className="flex-1 py-3 rounded-2xl bg-violet-600 hover:bg-violet-500 text-white font-semibold transition-all flex items-center justify-center gap-2"
                  >
                    Начать поездку <ChevronRight className="w-4 h-4" />
                  </button>
                ) : (
                  <button
                    onClick={completeTrip}
                    disabled={updateOrder.isPending}
                    className="flex-1 py-3 rounded-2xl bg-emerald-500 hover:bg-emerald-400 text-white font-semibold transition-all flex items-center justify-center gap-2"
                  >
                    Завершить <Check className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          </div>
        ) : (
          <div className="bg-[#0d0d1f] border border-white/[0.08] rounded-3xl p-8 text-center">
            {isOnline ? (
              <>
                <div className="w-16 h-16 rounded-2xl bg-violet-600/20 flex items-center justify-center mx-auto mb-4 relative">
                  <Zap className="w-8 h-8 text-violet-400 animate-pulse" />
                  <div className="absolute -top-1 -right-1 w-4 h-4 bg-emerald-500 rounded-full border-2 border-[#0d0d1f]" />
                </div>
                <p className="text-white/80 font-medium">Ожидаем заказы</p>
                <p className="text-white/40 text-sm mt-1.5">в городе <span className="text-white/70">{workCity}</span></p>
                <p className="text-white/20 text-xs mt-3">Перейдите в «Заказы» чтобы принять</p>
              </>
            ) : (
              <>
                <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mx-auto mb-4">
                  <Power className="w-8 h-8 text-white/20" />
                </div>
                <p className="text-white/40 font-medium">Вы оффлайн</p>
                <p className="text-white/20 text-sm mt-1">Нажмите кнопку выше, чтобы выйти на линию</p>
              </>
            )}
          </div>
        )}

        {/* Stats grid */}
        <div className="grid grid-cols-3 gap-3">
          <div className="bg-[#0d0d1f] border border-white/[0.08] rounded-2xl p-4">
            <div className="flex items-center gap-1.5 mb-2">
              <Wallet className="w-3.5 h-3.5 text-white/30" />
              <span className="text-xs text-white/30">Поездок</span>
            </div>
            <div className="text-xl font-bold text-white">{myProfile?.totalRides || 0}</div>
          </div>
          <div className="bg-[#0d0d1f] border border-white/[0.08] rounded-2xl p-4">
            <div className="flex items-center gap-1.5 mb-2">
              <Star className="w-3.5 h-3.5 text-white/30" />
              <span className="text-xs text-white/30">Рейтинг</span>
            </div>
            <div className="text-xl font-bold text-amber-400">{myProfile?.rating?.toFixed(1) || '5.0'}</div>
          </div>
          <div className="bg-[#0d0d1f] border border-white/[0.08] rounded-2xl p-4">
            <div className="flex items-center gap-1.5 mb-2">
              <Car className="w-3.5 h-3.5 text-white/30" />
              <span className="text-xs text-white/30">Авто</span>
            </div>
            <div className="text-sm font-semibold text-white leading-tight">{myProfile?.carModel || '—'}</div>
            <div className="text-xs text-white/40 mt-0.5">{myProfile?.carNumber || ''}</div>
          </div>
        </div>

        {/* Support button */}
        <button
          onClick={() => setShowSupport(true)}
          className="w-full flex items-center gap-3 px-4 py-3.5 bg-[#0d0d1f] border border-white/[0.08] rounded-2xl hover:border-violet-500/20 transition-all"
        >
          <div className="w-9 h-9 rounded-xl bg-violet-600/20 flex items-center justify-center">
            <Headphones className="w-4 h-4 text-violet-400" />
          </div>
          <div className="text-left">
            <div className="text-sm font-medium text-white">Техподдержка</div>
            <div className="text-xs text-white/40">Онлайн · Ответим быстро</div>
          </div>
          <ChevronRight className="w-4 h-4 text-white/20 ml-auto" />
        </button>
      </div>

      {showChat && activeOrder && (
        <OrderChat orderId={activeOrder.id} onClose={() => setShowChat(false)} />
      )}
      {showSupport && (
        <SupportChat onClose={() => setShowSupport(false)} />
      )}
    </MainLayout>
  );
}
