import { 
  useGetStats,
  useGetStatsByCity,
  useGetUsers,
  useGetTariffs,
  useCreateTariff,
  useUpdateTariff,
  useDeleteTariff,
  useGetCities,
  useGetTariffOptions,
  useCreateTariffOption,
  useUpdateTariffOption,
  useDeleteTariffOption,
} from "@workspace/api-client-react";
import { useAuthHeaders } from "./use-auth";
import { useQueryClient } from "@tanstack/react-query";

export function useStatsQuery() {
  const headers = useAuthHeaders();
  return useGetStats({ request: headers });
}

export function useStatsByCityQuery() {
  const headers = useAuthHeaders();
  return useGetStatsByCity({ request: headers });
}

export function useUsersQuery() {
  const headers = useAuthHeaders();
  return useGetUsers({ request: headers });
}

export function useTariffsQuery() {
  const headers = useAuthHeaders();
  return useGetTariffs({ request: headers });
}

export function useCitiesQuery() {
  const headers = useAuthHeaders();
  return useGetCities({ request: headers });
}

export function useTariffOptionsQuery() {
  const headers = useAuthHeaders();
  return useGetTariffOptions({ request: headers });
}

export function useCreateTariffMutation() {
  const headers = useAuthHeaders();
  const queryClient = useQueryClient();
  return useCreateTariff({
    request: headers,
    mutation: {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ['/api/tariffs'] })
    }
  });
}

export function useUpdateTariffMutation() {
  const headers = useAuthHeaders();
  const queryClient = useQueryClient();
  return useUpdateTariff({
    request: headers,
    mutation: {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ['/api/tariffs'] })
    }
  });
}

export function useDeleteTariffMutation() {
  const headers = useAuthHeaders();
  const queryClient = useQueryClient();
  return useDeleteTariff({
    request: headers,
    mutation: {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ['/api/tariffs'] })
    }
  });
}

export function useCreateTariffOptionMutation() {
  const headers = useAuthHeaders();
  const queryClient = useQueryClient();
  return useCreateTariffOption({
    request: headers,
    mutation: {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ['/api/tariff-options'] })
    }
  });
}

export function useUpdateTariffOptionMutation() {
  const headers = useAuthHeaders();
  const queryClient = useQueryClient();
  return useUpdateTariffOption({
    request: headers,
    mutation: {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ['/api/tariff-options'] })
    }
  });
}

export function useDeleteTariffOptionMutation() {
  const headers = useAuthHeaders();
  const queryClient = useQueryClient();
  return useDeleteTariffOption({
    request: headers,
    mutation: {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ['/api/tariff-options'] })
    }
  });
}
