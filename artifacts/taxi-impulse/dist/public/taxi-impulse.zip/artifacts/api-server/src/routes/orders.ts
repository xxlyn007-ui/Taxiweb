import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db, ordersTable, usersTable, driversTable, tariffsTable } from "@workspace/db";
import {
  GetOrdersResponse,
  GetOrdersQueryParams,
  CreateOrderBody,
  EstimatePriceBody,
  EstimatePriceResponse,
  GetOrderByIdParams,
  GetOrderByIdResponse,
  UpdateOrderParams,
  UpdateOrderBody,
  UpdateOrderResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

function toDate(val: any): Date | undefined {
  if (!val) return undefined;
  if (val instanceof Date) return val;
  return new Date(val);
}

function estimateDistance(fromAddr: string, toAddr: string, _city: string): number {
  const fnv = (s: string): number => {
    let h = 2166136261;
    for (let i = 0; i < s.length; i++) {
      h = ((h ^ s.charCodeAt(i)) * 16777619) >>> 0;
    }
    return h;
  };

  const from = fromAddr.toLowerCase().trim();
  const to = toAddr.toLowerCase().trim();

  const streetRe = /(?:ул(?:ица)?\.?\s+|пр(?:осп(?:ект)?)?\.?\s+|пер(?:еулок)?\.?\s+|бул(?:ьвар)?\.?\s+|пл(?:ощадь)?\.?\s+|ш(?:оссе)?\.?\s+)([а-яёa-z\-]+)/i;
  const numRe = /\b(\d+)\b/;

  const fromStreet = from.match(streetRe)?.[1] ?? '';
  const toStreet = to.match(streetRe)?.[1] ?? '';
  const fromNum = parseInt(from.match(numRe)?.[1] ?? '0');
  const toNum = parseInt(to.match(numRe)?.[1] ?? '0');

  let km: number;
  if (fromStreet && toStreet && fromStreet === toStreet && fromNum && toNum) {
    const diff = Math.abs(fromNum - toNum);
    km = Math.max(0.5, Math.min(6, diff * 0.08 + 0.5));
  } else {
    const h = fnv(from + '\x00' + to) % 170;
    km = 2 + h * 0.12;
  }

  return Math.round(km * 10) / 10;
}

function calculateTieredPrice(distance: number, tariff: typeof tariffsTable.$inferSelect): number {
  const t1max = tariff.tier1MaxKm ?? 5;
  const t1price = tariff.tier1PricePerKm ?? tariff.pricePerKm;
  const t2max = tariff.tier2MaxKm ?? 10;
  const t2price = tariff.tier2PricePerKm ?? tariff.pricePerKm;
  const t3max = tariff.tier3MaxKm ?? 15;
  const t3price = tariff.tier3PricePerKm ?? tariff.pricePerKm;

  let total = tariff.basePrice;
  let rem = distance;

  const seg1 = Math.min(rem, t1max);
  total += seg1 * t1price;
  rem -= seg1;
  if (rem <= 0) return Math.max(tariff.minPrice, Math.round(total));

  const seg2 = Math.min(rem, t2max - t1max);
  total += seg2 * t2price;
  rem -= seg2;
  if (rem <= 0) return Math.max(tariff.minPrice, Math.round(total));

  const seg3 = Math.min(rem, t3max - t2max);
  total += seg3 * t3price;
  rem -= seg3;
  if (rem <= 0) return Math.max(tariff.minPrice, Math.round(total));

  total += rem * tariff.pricePerKm;
  return Math.max(tariff.minPrice, Math.round(total));
}

async function enrichOrder(order: any) {
  const [passenger] = await db.select().from(usersTable).where(eq(usersTable.id, order.passengerId));
  let driverName = null, driverPhone = null, driverCar = null, driverCarNumber = null;
  if (order.driverId) {
    const [driver] = await db.select().from(driversTable).where(eq(driversTable.id, order.driverId));
    if (driver) {
      const [driverUser] = await db.select().from(usersTable).where(eq(usersTable.id, driver.userId));
      driverName = driverUser?.name || null;
      driverPhone = driverUser?.phone || null;
      driverCar = driver.carModel || null;
      driverCarNumber = driver.carNumber || null;
    }
  }
  return {
    id: order.id,
    passengerId: order.passengerId,
    passengerName: passenger?.name || "Неизвестно",
    passengerPhone: passenger?.phone || "",
    driverId: order.driverId,
    driverName,
    driverPhone,
    driverCar,
    driverCarNumber,
    city: order.city,
    fromAddress: order.fromAddress,
    toAddress: order.toAddress,
    status: order.status,
    price: order.price,
    distance: order.distance,
    tariffName: order.tariffName,
    comment: order.comment,
    rating: order.rating,
    createdAt: toDate(order.createdAt),
    acceptedAt: toDate(order.acceptedAt),
    completedAt: toDate(order.completedAt),
  };
}

router.get("/orders", async (req, res): Promise<void> => {
  const queryParams = GetOrdersQueryParams.safeParse(req.query);
  let orders = await db.select().from(ordersTable).orderBy(sql`${ordersTable.createdAt} DESC`);

  if (queryParams.success) {
    if (queryParams.data.status) orders = orders.filter(o => o.status === queryParams.data.status);
    if (queryParams.data.driverId) orders = orders.filter(o => o.driverId === queryParams.data.driverId);
    if (queryParams.data.passengerId) orders = orders.filter(o => o.passengerId === queryParams.data.passengerId);
  }

  const enriched = await Promise.all(orders.map(enrichOrder));
  res.json(GetOrdersResponse.parse(enriched));
});

router.post("/orders/estimate", async (req, res): Promise<void> => {
  const parsed = EstimatePriceBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Неверные данные" });
    return;
  }

  let tariff: typeof tariffsTable.$inferSelect | null = null;
  let tariffName = "Стандарт";

  if (parsed.data.tariffId) {
    const [t] = await db.select().from(tariffsTable).where(eq(tariffsTable.id, parsed.data.tariffId));
    if (t) { tariff = t; tariffName = t.name; }
  }

  const estimatedDistance = estimateDistance(parsed.data.fromAddress, parsed.data.toAddress, parsed.data.city);
  let estimatedPrice: number;

  if (tariff) {
    estimatedPrice = calculateTieredPrice(estimatedDistance, tariff);
  } else {
    estimatedPrice = Math.max(150, Math.round(100 + 25 * estimatedDistance));
  }

  const estimatedDuration = Math.round(estimatedDistance * 3 + 5);
  res.json(EstimatePriceResponse.parse({ estimatedPrice, estimatedDistance, estimatedDuration, tariffName }));
});

router.post("/orders", async (req, res): Promise<void> => {
  const parsed = CreateOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Неверные данные" });
    return;
  }

  let tariffName = "Стандарт", price = 150;
  let tariff: typeof tariffsTable.$inferSelect | null = null;

  if (parsed.data.tariffId) {
    const [t] = await db.select().from(tariffsTable).where(eq(tariffsTable.id, parsed.data.tariffId));
    if (t) { tariff = t; tariffName = t.name; }
  }

  const distance = estimateDistance(parsed.data.fromAddress, parsed.data.toAddress, parsed.data.city);
  if (tariff) {
    price = calculateTieredPrice(distance, tariff);
  }

  const [order] = await db.insert(ordersTable).values({
    passengerId: parsed.data.passengerId,
    city: parsed.data.city,
    fromAddress: parsed.data.fromAddress,
    toAddress: parsed.data.toAddress,
    tariffId: parsed.data.tariffId,
    tariffName,
    price,
    distance,
    comment: parsed.data.comment,
    status: "pending",
  }).returning();

  const enriched = await enrichOrder(order);
  res.status(201).json(enriched);
});

router.get("/orders/:id", async (req, res): Promise<void> => {
  const params = GetOrderByIdParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Неверный ID" });
    return;
  }
  const [order] = await db.select().from(ordersTable).where(eq(ordersTable.id, params.data.id));
  if (!order) {
    res.status(404).json({ error: "Заказ не найден" });
    return;
  }
  const enriched = await enrichOrder(order);
  res.json(GetOrderByIdResponse.parse(enriched));
});

router.patch("/orders/:id", async (req, res): Promise<void> => {
  const params = UpdateOrderParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: "Неверный ID" });
    return;
  }
  const parsed = UpdateOrderBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Неверные данные" });
    return;
  }

  const updateData: any = { ...parsed.data };

  if (parsed.data.status === "accepted") {
    updateData.acceptedAt = new Date();
    if (parsed.data.driverId) {
      await db.update(driversTable).set({ status: "busy" }).where(eq(driversTable.id, parsed.data.driverId));
    }
  }
  if (parsed.data.status === "completed") {
    updateData.completedAt = new Date();
    const [existingOrder] = await db.select().from(ordersTable).where(eq(ordersTable.id, params.data.id));
    const driverIdToUpdate = parsed.data.driverId || existingOrder?.driverId;
    if (driverIdToUpdate) {
      const [driver] = await db.select().from(driversTable).where(eq(driversTable.id, driverIdToUpdate));
      if (driver) {
        await db.update(driversTable).set({
          totalRides: (driver.totalRides || 0) + 1,
          status: "online",
          balance: (driver.balance || 0) + (updateData.price || existingOrder?.price || 0) * 0.8,
        }).where(eq(driversTable.id, driverIdToUpdate));
      }
    }
    if (existingOrder) {
      const [passenger] = await db.select().from(usersTable).where(eq(usersTable.id, existingOrder.passengerId));
      if (passenger) {
        await db.update(usersTable).set({ totalRides: (passenger.totalRides || 0) + 1 }).where(eq(usersTable.id, existingOrder.passengerId));
      }
    }
  }

  if (parsed.data.status === "cancelled") {
    const [existingOrder] = await db.select().from(ordersTable).where(eq(ordersTable.id, params.data.id));
    const driverIdToFree = existingOrder?.driverId;
    if (driverIdToFree) {
      await db.update(driversTable).set({ status: "online" }).where(eq(driversTable.id, driverIdToFree));
    }
  }

  const [order] = await db.update(ordersTable).set(updateData).where(eq(ordersTable.id, params.data.id)).returning();
  if (!order) {
    res.status(404).json({ error: "Заказ не найден" });
    return;
  }
  const enriched = await enrichOrder(order);
  res.json(UpdateOrderResponse.parse(enriched));
});

router.post("/orders/:id/rate", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Неверный ID" }); return; }

  const rating = parseInt(req.body.rating);
  if (!rating || rating < 1 || rating > 5) {
    res.status(400).json({ error: "Оценка должна быть от 1 до 5" });
    return;
  }

  const [existingOrder] = await db.select().from(ordersTable).where(eq(ordersTable.id, id));
  if (!existingOrder) { res.status(404).json({ error: "Заказ не найден" }); return; }
  if (existingOrder.rating) { res.status(400).json({ error: "Заказ уже оценён" }); return; }

  const [order] = await db.update(ordersTable).set({ rating }).where(eq(ordersTable.id, id)).returning();

  if (existingOrder.driverId) {
    const [driver] = await db.select().from(driversTable).where(eq(driversTable.id, existingOrder.driverId));
    if (driver) {
      const totalRides = driver.totalRides || 1;
      const oldRating = driver.rating || 5;
      const ratedOrders = Math.min(totalRides, 100);
      const newRating = ((oldRating * (ratedOrders - 1)) + rating) / ratedOrders;
      await db.update(driversTable).set({ rating: Math.round(newRating * 10) / 10 }).where(eq(driversTable.id, existingOrder.driverId));
    }
  }

  const enriched = await enrichOrder(order);
  res.json(enriched);
});

export default router;
