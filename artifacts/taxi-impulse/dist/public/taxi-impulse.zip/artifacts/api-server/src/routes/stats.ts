import { Router, type IRouter } from "express";
import { db, ordersTable, driversTable, usersTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/stats", async (_req, res): Promise<void> => {
  const allOrders = await db.select().from(ordersTable);
  const allDrivers = await db.select().from(driversTable);
  const allUsers = await db.select().from(usersTable);

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const ordersToday = allOrders.filter(o => o.createdAt && o.createdAt >= today).length;
  const activeDrivers = allDrivers.filter(d => d.status === "online" || d.status === "busy").length;
  const completedOrders = allOrders.filter(o => o.status === "completed");
  const cancelledOrders = allOrders.filter(o => o.status === "cancelled").length;
  const pendingOrders = allOrders.filter(o => o.status === "pending").length;
  const revenue = completedOrders.reduce((sum, o) => sum + (o.price || 0), 0);
  const revenueToday = completedOrders.filter(o => o.completedAt && o.completedAt >= today).reduce((sum, o) => sum + (o.price || 0), 0);
  const allRatings = allOrders.filter(o => o.rating != null).map(o => o.rating!);
  const avgRating = allRatings.length > 0 ? allRatings.reduce((a, b) => a + b, 0) / allRatings.length : 5.0;
  const passengers = allUsers.filter(u => u.role === "passenger").length;

  res.json({
    totalOrders: allOrders.length,
    ordersToday,
    activeDrivers,
    totalDrivers: allDrivers.length,
    totalPassengers: passengers,
    revenue: Math.round(revenue * 100) / 100,
    revenueToday: Math.round(revenueToday * 100) / 100,
    completedOrders: completedOrders.length,
    cancelledOrders,
    pendingOrders,
    avgRating: Math.round(avgRating * 10) / 10,
  });
});

router.get("/stats/by-city", async (_req, res): Promise<void> => {
  const allOrders = await db.select().from(ordersTable);
  const allDrivers = await db.select().from(driversTable);

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const citySet = new Set<string>();
  allOrders.forEach(o => o.city && citySet.add(o.city));
  allDrivers.forEach(d => (d.workCity || d.city) && citySet.add((d.workCity || d.city)!));

  const result = Array.from(citySet).map(city => {
    const cityOrders = allOrders.filter(o => o.city === city);
    const cityDrivers = allDrivers.filter(d => (d.workCity || d.city) === city);
    return {
      city,
      ordersToday: cityOrders.filter(o => o.createdAt && o.createdAt >= today).length,
      totalOrders: cityOrders.length,
      driversOnline: cityDrivers.filter(d => d.status === 'online' || d.status === 'busy').length,
      totalDrivers: cityDrivers.length,
    };
  }).filter(c => c.totalOrders > 0 || c.totalDrivers > 0)
    .sort((a, b) => b.totalOrders - a.totalOrders);

  res.json(result);
});

export default router;
