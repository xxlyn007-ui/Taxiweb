import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, driversTable, usersTable, tariffsTable } from "@workspace/db";

const router: IRouter = Router();

function toDate(val: any): Date | undefined {
  if (!val) return undefined;
  if (val instanceof Date) return val;
  return new Date(val);
}

async function enrichDriver(driver: any) {
  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, driver.userId));
  let tariffName = null;
  if (driver.tariffId) {
    const [tariff] = await db.select().from(tariffsTable).where(eq(tariffsTable.id, driver.tariffId));
    tariffName = tariff?.name || null;
  }
  return {
    id: driver.id,
    userId: driver.userId,
    name: user?.name || "Неизвестно",
    phone: user?.phone || "",
    city: driver.city,
    workCity: driver.workCity,
    carModel: driver.carModel,
    carColor: driver.carColor,
    carNumber: driver.carNumber,
    licenseNumber: driver.licenseNumber,
    experience: driver.experience,
    status: driver.status,
    rating: driver.rating,
    totalRides: driver.totalRides,
    balance: driver.balance,
    tariffId: driver.tariffId,
    tariffName,
    isApproved: driver.isApproved,
    isBlocked: driver.isBlocked,
    autoAssign: driver.autoAssign,
    rejectionReason: driver.rejectionReason,
    createdAt: toDate(driver.createdAt),
  };
}

router.get("/drivers", async (req, res): Promise<void> => {
  let drivers = await db.select().from(driversTable);
  const { status, city, isApproved, pendingApproval } = req.query as any;

  if (status) drivers = drivers.filter(d => d.status === status);
  if (city) drivers = drivers.filter(d => (d.workCity || d.city) === city);
  if (isApproved !== undefined) drivers = drivers.filter(d => d.isApproved === (isApproved === 'true'));
  if (pendingApproval === 'true') drivers = drivers.filter(d => !d.isApproved && !d.isBlocked && !d.rejectionReason);

  const enriched = await Promise.all(drivers.map(enrichDriver));
  res.json(enriched);
});

router.post("/drivers", async (req, res): Promise<void> => {
  const { userId, carModel, carColor, carNumber, city, workCity, tariffId, licenseNumber, experience } = req.body;
  if (!userId || !carModel || !carNumber || !city) {
    res.status(400).json({ error: "Неверные данные" });
    return;
  }
  const [driver] = await db.insert(driversTable).values({
    userId, carModel, carColor, carNumber, city, workCity: workCity || city, tariffId, licenseNumber, experience
  }).returning();
  const enriched = await enrichDriver(driver);
  res.status(201).json(enriched);
});

router.get("/drivers/:id", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Неверный ID" }); return; }
  const [driver] = await db.select().from(driversTable).where(eq(driversTable.id, id));
  if (!driver) { res.status(404).json({ error: "Водитель не найден" }); return; }
  const enriched = await enrichDriver(driver);
  res.json(enriched);
});

router.patch("/drivers/:id", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Неверный ID" }); return; }
  const allowed = ['carModel', 'carColor', 'carNumber', 'city', 'workCity', 'tariffId', 'isApproved', 'isBlocked', 'autoAssign', 'balance', 'licenseNumber', 'experience', 'rejectionReason'];
  const updateData: any = {};
  for (const key of allowed) {
    if (req.body[key] !== undefined) updateData[key] = req.body[key];
  }
  const [driver] = await db.update(driversTable).set(updateData).where(eq(driversTable.id, id)).returning();
  if (!driver) { res.status(404).json({ error: "Водитель не найден" }); return; }
  const enriched = await enrichDriver(driver);
  res.json(enriched);
});

router.patch("/drivers/:id/status", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Неверный ID" }); return; }
  const { status } = req.body;
  if (!['online', 'offline', 'busy'].includes(status)) {
    res.status(400).json({ error: "Неверный статус" });
    return;
  }
  const [driver] = await db.update(driversTable).set({ status }).where(eq(driversTable.id, id)).returning();
  if (!driver) { res.status(404).json({ error: "Водитель не найден" }); return; }
  const enriched = await enrichDriver(driver);
  res.json(enriched);
});

router.patch("/drivers/:id/block", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Неверный ID" }); return; }
  const { isBlocked } = req.body;
  const [driver] = await db.update(driversTable).set({ isBlocked: !!isBlocked, status: isBlocked ? 'offline' : 'offline' }).where(eq(driversTable.id, id)).returning();
  if (!driver) { res.status(404).json({ error: "Водитель не найден" }); return; }
  const enriched = await enrichDriver(driver);
  res.json(enriched);
});

router.patch("/drivers/:id/approve", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) { res.status(400).json({ error: "Неверный ID" }); return; }
  const { isApproved, rejectionReason } = req.body;
  const updateData: any = { isApproved: !!isApproved };
  if (rejectionReason) updateData.rejectionReason = rejectionReason;
  const [driver] = await db.update(driversTable).set(updateData).where(eq(driversTable.id, id)).returning();
  if (!driver) { res.status(404).json({ error: "Водитель не найден" }); return; }
  const enriched = await enrichDriver(driver);
  res.json(enriched);
});

export default router;
