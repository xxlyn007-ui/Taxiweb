import { Router, type IRouter } from "express";
import { eq } from "drizzle-orm";
import { db, chatMessagesTable, usersTable } from "@workspace/db";

const router: IRouter = Router();

router.get("/chat/:orderId/messages", async (req, res): Promise<void> => {
  const orderId = parseInt(req.params.orderId);
  if (isNaN(orderId)) { res.status(400).json({ error: "Неверный ID заказа" }); return; }

  const messages = await db
    .select()
    .from(chatMessagesTable)
    .where(eq(chatMessagesTable.orderId, orderId))
    .orderBy(chatMessagesTable.createdAt);

  const enriched = await Promise.all(messages.map(async (msg) => {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, msg.senderId));
    return {
      id: msg.id,
      orderId: msg.orderId,
      senderId: msg.senderId,
      senderName: user?.name || "Неизвестно",
      senderRole: msg.senderRole,
      message: msg.message,
      createdAt: msg.createdAt,
    };
  }));

  res.json(enriched);
});

router.post("/chat/:orderId/messages", async (req, res): Promise<void> => {
  const orderId = parseInt(req.params.orderId);
  if (isNaN(orderId)) { res.status(400).json({ error: "Неверный ID заказа" }); return; }

  const { senderId, senderRole, message } = req.body;
  if (!senderId || !senderRole || !message?.trim()) {
    res.status(400).json({ error: "Неверные данные" });
    return;
  }

  const [msg] = await db.insert(chatMessagesTable).values({
    orderId,
    senderId,
    senderRole,
    message: message.trim(),
  }).returning();

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, senderId));

  res.status(201).json({
    id: msg.id,
    orderId: msg.orderId,
    senderId: msg.senderId,
    senderName: user?.name || "Неизвестно",
    senderRole: msg.senderRole,
    message: msg.message,
    createdAt: msg.createdAt,
  });
});

export default router;
