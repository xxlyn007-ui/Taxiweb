import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import citiesRouter from "./cities";
import tariffsRouter from "./tariffs";
import tariffOptionsRouter from "./tariff-options";
import driversRouter from "./drivers";
import usersRouter from "./users";
import ordersRouter from "./orders";
import statsRouter from "./stats";
import chatRouter from "./chat";
import supportRouter from "./support";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(citiesRouter);
router.use(tariffsRouter);
router.use(tariffOptionsRouter);
router.use(driversRouter);
router.use(usersRouter);
router.use(ordersRouter);
router.use(statsRouter);
router.use(chatRouter);
router.use(supportRouter);

export default router;
