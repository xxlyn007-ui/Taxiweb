import { Router, type IRouter } from "express";
import { GetCitiesResponse } from "@workspace/api-zod";

const router: IRouter = Router();

const KRASNOYARSK_CITIES = [
  { id: 1, name: "Красноярск", region: "Красноярский край" },
  { id: 2, name: "Норильск", region: "Красноярский край" },
  { id: 3, name: "Ачинск", region: "Красноярский край" },
  { id: 4, name: "Канск", region: "Красноярский край" },
  { id: 5, name: "Железногорск", region: "Красноярский край" },
  { id: 6, name: "Зеленогорск", region: "Красноярский край" },
  { id: 7, name: "Минусинск", region: "Красноярский край" },
  { id: 8, name: "Дивногорск", region: "Красноярский край" },
  { id: 9, name: "Лесосибирск", region: "Красноярский край" },
  { id: 10, name: "Сосновоборск", region: "Красноярский край" },
  { id: 11, name: "Енисейск", region: "Красноярский край" },
  { id: 12, name: "Шарыпово", region: "Красноярский край" },
  { id: 13, name: "Назарово", region: "Красноярский край" },
  { id: 14, name: "Бородино", region: "Красноярский край" },
  { id: 15, name: "Игарка", region: "Красноярский край" },
  { id: 16, name: "Заозёрный", region: "Красноярский край" },
  { id: 17, name: "Кодинск", region: "Красноярский край" },
  { id: 18, name: "Уяр", region: "Красноярский край" },
  { id: 19, name: "Иланский", region: "Красноярский край" },
  { id: 20, name: "Козулька", region: "Красноярский край" },
];

router.get("/cities", async (_req, res): Promise<void> => {
  res.json(GetCitiesResponse.parse(KRASNOYARSK_CITIES));
});

export default router;
